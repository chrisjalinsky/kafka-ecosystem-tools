var supportedConnectorsTemplates = [
 {
  name: "Twitter",
  icon: 'twitter.png',
  description: 'Use the Twitter API to stream data into Kafka',
  type: "Source",
  uiEnabled: true,
  color: "#1da1f3",
  class: "com.eneco.trading.kafka.connect.twitter.TwitterSourceConnector",
  docs: "com.eneco.trading.kafka.connect.twitter.TwitterSourceConnector.html"
 },
 {
  name: "Yahoo Finance",
  type: "Source",
  icon: "yahoofinance.png",
  description: "Stream stock and currency exchange rates into Kafka",
  uiEnabled: true,
  color: "#30007b",
  class: "com.datamountaineer.streamreactor.connect.yahoo.source.YahooSourceConnector",
  docs: "com.datamountaineer.streamreactor.connect.yahoo.source.YahooSourceConnector.html"
 },
 {
  name: "File",
  icon: "file.png",
  description: "Tail files or folders and stream data into Kafka",
  type: "Source",
  uiEnabled: true,
  color: "#bbb2b2",
  class: "org.apache.kafka.connect.file.FileStreamSourceConnector",
  docs: "org.apache.kafka.connect.file.FileStreamSourceConnector.html"
 },
 {
   name: "Ftp",
   icon: "ftp.png",
   description: "Tail remote FTP folders and bring messages in Kafka",
   type: "Source",
   uiEnabled: true,
   color: "#b1b1b1",
   class: "com.datamountaineer.streamreactor.connect.ftp.FtpSourceConnector",
   docs: "com.datamountaineer.streamreactor.connect.ftp.FtpSourceConnector.html"
 },
 {
  name: "Blockchain",
  icon: "blockchain-logo.jpg",
  description: "Get blockchain.info data into Kafka",
  type: "Source",
  uiEnabled: true,
  color: "#b1b1b1",
  class: "com.datamountaineer.streamreactor.connect.blockchain.source.BlockchainSourceConnector",
  docs: "com.datamountaineer.streamreactor.connect.blockchain.source.BlockchainSourceConnector.html"
 },
 {
  name: "Jdbc",
  icon: "database.png",
  description: "Stream data from SQL server into Kafka",
  type: "Source",
  uiEnabled: true,
  color: "#b1b1b1",
  class: "io.confluent.connect.jdbc.JdbcSourceConnector",
  docs: "io.confluent.connect.jdbc.JdbcSourceConnector.html",
 },
 {
  name: "Cassandra",
  icon: "cassandra.jpg",
  description: "Extract Cassandra data using the CQL driver into Kafka",
  uiEnabled: true,
  type: "Source",
  color: "",
  class: "com.datamountaineer.streamreactor.connect.cassandra.source.CassandraSourceConnector",
  docs: "com.datamountaineer.streamreactor.connect.cassandra.source.CassandraSourceConnector.html",
 },
 {
  name: "Bloomberg",
  icon: "bloomberg.png",
  description: "Use the Bloomberg API to stream data into Kafka",
  type: "Source",
  uiEnabled: true,
  color: "#a65674",
  class: "com.datamountaineer.streamreactor.connect.bloomberg.BloombergSourceConnector",
  docs: "com.datamountaineer.streamreactor.connect.bloomberg.BloombergSourceConnector.html"
 },
 {
  name: "JMS",
  icon: "jms.png",
  description: "Get data from JMS into Kafka",
  type: "Source",
  uiEnabled: true,
  color: "pink",
  class: "com.datamountaineer.streamreactor.connect.jms.source.JMSSourceConnector",
  docs: "com.datamountaineer.streamreactor.connect.jms.source.JMSSourceConnector.html"
 },
 {
  name: "MQTT",
  icon: "mqtt.png",
  description: "Read data from MQTT and write them into Kafka",
  type: "Source",
  uiEnabled: true,
  color: "#5B346C",
  class: "com.datamountaineer.streamreactor.connect.mqtt.source.MqttSourceConnector",
  docs: "com.datamountaineer.streamreactor.connect.mqtt.source.MqttSourceConnector.html",
 },
 {
  name: "RethinkDB",
  type: "Source",
  icon: "rethink.png",
  description: "Source records from RethinkDB into Kafka",
  color: "#4A3A41",
  uiEnabled: true,
  class: "com.datamountaineer.streamreactor.connect.rethink.source.ReThinkSourceConnector",
  docs: "com.datamountaineer.streamreactor.connect.rethink.source.ReThinkSourceConnector.html",
 },
 {
  name: "CoAP",
  type: "Source",
  icon: "coap.png",
  description: "Get Constrained Application Protocol data into Kafka",
  color: "#3A3A3A",
  uiEnabled: true,
  class: "com.datamountaineer.streamreactor.connect.coap.source.CoapSourceConnector",
  docs: "com.datamountaineer.streamreactor.connect.coap.source.CoapSourceConnector.html",
 },
 {
  name: "Schemas",
  type: "Source",
  icon: "avro.svg",
  description: "Store Avro schemas in HDFS",
  color: "#3A3A3A",
  uiEnabled: true,
  class: "io.confluent.connect.hdfs.tools.SchemaSourceConnector",
  docs: "io.confluent.connect.hdfs.tools.SchemaSourceConnector.html",
 },
 {
  name: "Schemas",
  type: "Source",
  icon: "avro.svg",
  description: "Get Avro schemas into Kafka",
  color: "#3A3A3A",
  uiEnabled: true,
  class: "io.confluent.connect.storage.tools.SchemaSourceConnector",
  docs: "io.confluent.connect.storage.tools.SchemaSourceConnector.html",
 },
 {
  name: "Kafka Replicator",
  type: "Source",
  icon: "replicate.png",
  description: "Replicate data to another Kafka cluster",
  color: "#3A3A3A",
  uiEnabled: true,
  class: "io.confluent.connect.replicator.ReplicatorSourceConnector",
  docs: "io.confluent.connect.replicator.ReplicatorSourceConnector.html",
 },



 {
  name: "Elastic Search",
  color: "#5CB85C",
  icon: "elastic.png",
  description: "Write data from Kafka to Elastic Search",
  type: "Sink",
  uiEnabled: true,
  class: "com.datamountaineer.streamreactor.connect.elastic.ElasticSinkConnector",
  docs: "com.datamountaineer.streamreactor.connect.elastic.ElasticSinkConnector.html",
 },
 {
  name: "Cassandra",
  icon: "cassandra.jpg",
  description: "Store Kafka data into Cassandra",
  uiEnabled: true,
  type: "Sink",
  color: "#1a9f85",
  class: "com.datamountaineer.streamreactor.connect.cassandra.sink.CassandraSinkConnector",
  docs: "com.datamountaineer.streamreactor.connect.cassandra.sink.CassandraSinkConnector.html",
 },
 {
  name: "InfluxDB",
  icon: "influxdb.jpg",
  description: "Store Kafka data into InfluxDB",
  uiEnabled: true,
  type: "Sink",
  color: "#0090BA",
  class: "com.datamountaineer.streamreactor.connect.influx.InfluxSinkConnector",
  docs: "com.datamountaineer.streamreactor.connect.influx.InfluxSinkConnector.html",
 },
 {
  name: "MongoDB",
  type: "Sink",
  icon: "mongodb.png",
  description: "Write Kafka data into MongoDB",
  color: "#609959",
  uiEnabled: true,
  class: "com.datamountaineer.streamreactor.connect.mongodb.sink.MongoSinkConnector",
  docs: "com.datamountaineer.streamreactor.connect.mongodb.sink.MongoSinkConnector.html",
 },
 {
  name: "HazelCast",
  type: "Sink",
  description: "Store Kafka data into HazelCast (RingBuffer)",
  icon: "hazelcast.png",
  uiEnabled: true,
  color: "#002A36",
  class: "com.datamountaineer.streamreactor.connect.hazelcast.sink.HazelCastSinkConnector",
  docs: "com.datamountaineer.streamreactor.connect.hazelcast.sink.HazelCastSinkConnector.html",
 },
 {
  name: "Jdbc",
  icon: 'database.png',
  description: 'Store Kafka data into SQL',
  type: "Sink",
  uiEnabled: true,
  color: "#D8291F",
  class: "io.confluent.connect.jdbc.JdbcSinkConnector",
  docs: "io.confluent.connect.jdbc.JdbcSinkConnector.html",
 },
 {
  name: "Amazon S3",
  type: "Sink",
  icon: "s3.png",
  description: "Store Kafka data into Amazon S3",
  color: "#3A3A3A",
  uiEnabled: true,
  class: "io.confluent.connect.s3.S3SinkConnector",
  docs: "io.confluent.connect.s3.S3SinkConnector.html",
 },
 {
  name: "DocumentDB",
  type: "Sink",
  icon: "documentdb.png",
  description: "Write Kafka data into Azure Document DB",
  color: "#3A3A3A",
  uiEnabled: true,
  class: "com.datamountaineer.streamreactor.connect.azure.documentdb.sink.DocumentDbSinkConnector",
  docs: "com.datamountaineer.streamreactor.connect.azure.documentdb.sink.DocumentDbSinkConnector.html",
 },
 {
  name: "Redis",
  icon: 'redis.png',
  description: 'Store Kafka data into Redis Sorted Sets/Key-Value',
  type: "Sink",
  uiEnabled: true,
  color: "#D8291F",
  class: "com.datamountaineer.streamreactor.connect.redis.sink.RedisSinkConnector",
  docs: "com.datamountaineer.streamreactor.connect.redis.sink.RedisSinkConnector.html",
 },
 {
  name: "Kudu",
  icon: 'kudu.png',
  type: "Sink",
  description: "Write Kafka data into Kudu",
  uiEnabled: true,
  color: "#549998",
  class: "com.datamountaineer.streamreactor.connect.kudu.sink.KuduSinkConnector",
  docs: "com.datamountaineer.streamreactor.connect.kudu.sink.KuduSinkConnector.html",
 },
 {
  name: "JMS",
  type: "Sink",
  icon: "jms.png",
  description: "Store Kafka data into a JMS topic/queue",
  uiEnabled: true,
  color: "#879171",
  class: "com.datamountaineer.streamreactor.connect.jms.sink.JMSSinkConnector",
  docs: "com.datamountaineer.streamreactor.connect.jms.sink.JMSSinkConnector.html",
 },
 {
  name: "HDFS",
  type: "Sink",
  description: "Write Kafka data into HDFS",
  icon: "hdfs.png",
  uiEnabled: true,
  color: "#ffcccc",
  class: "io.confluent.connect.hdfs.HdfsSinkConnector",
  docs: "io.confluent.connect.hdfs.HdfsSinkConnector.html",
 }, {
  name: "VoltDB",
  type: "Sink",
  icon: "voltdb.png",
  uiEnabled: true,
  description: 'A sink connector to write Kafka data into VoltDB',
  color: "#e8371b",
  class: "com.datamountaineer.streamreactor.connect.voltdb.VoltSinkConnector",
  docs: "com.datamountaineer.streamreactor.connect.voltdb.VoltSinkConnector.html",
 },
 {
  name: "File",
  icon: "file.png",
  description: "Store Kafka data into files",
  type: "Sink",
  uiEnabled: true,
  color: "#b1b1b1",
  class: "org.apache.kafka.connect.file.FileStreamSinkConnector",
  docs: "org.apache.kafka.connect.file.FileStreamSinkConnector.html",
 },
 {
  name: "CoAP",
  type: "Sink",
  icon: "coap.png",
  description: "Transfer Kafka data into Constrained Application Protocol service",
  color: "#3A3A3A",
  uiEnabled: true,
  class: "com.datamountaineer.streamreactor.connect.coap.sink.CoapSinkConnector",
  docs: "com.datamountaineer.streamreactor.connect.coap.sink.CoapSinkConnector.html",
 },
 {
  name: "HBase",
  icon: "hbase.svg",
  type: "Sink",
  description: "Write Kafka data into HBase",
  uiEnabled: true,
  color: "#6d1c7c",
  class: "com.datamountaineer.streamreactor.connect.hbase.HbaseSinkConnector",
  docs: "com.datamountaineer.streamreactor.connect.hbase.HbaseSinkConnector.html",
 },
 {
  name: "RethinkDB",
  type: "Sink",
  icon: "rethink.png",
  description: "Store Kafka data into RethinkDb",
  uiEnabled: true,
  color: "#4A3A41",
  class: "com.datamountaineer.streamreactor.connect.rethink.sink.ReThinkSinkConnector",
  docs: "com.datamountaineer.streamreactor.connect.rethink.sink.ReThinkSinkConnector.html",
 },
 {
  name: "ElasticSearch (confluent)",
  type: "Sink",
  icon: "elastic.png",
  description: "Write Kafka data into Elastic Search",
  uiEnabled: true,
  color: "#4A3A41",
  class: "io.confluent.connect.elasticsearch.ElasticsearchSinkConnector",
  docs: "io.confluent.connect.elasticsearch.ElasticsearchSinkConnector.html",
 }, {
  name: "Druid",
  type: "Sink",
  icon: "druid.png",
  description: "Write Kafka data into Apache Druid Search",
  uiEnabled: true,
  color: "#4A3A41",
  class: "com.datamountaineer.streamreactor.connect.druid.DruidSinkConnector",
  docs: "com.datamountaineer.streamreactor.connect.druid.DruidSinkConnector.html",
 },
 {
  name: "Twitter",
  type: "Sink",
  icon: "twitter.png",
  description: "Push Kafka events to Twitter",
  uiEnabled: true,
  color: "#4A3A41",
  class: "com.eneco.trading.kafka.connect.twitter.TwitterSinkConnector",
  docs: "com.eneco.trading.kafka.connect.twitter.TwitterSinkConnector.html",
 }
];

var defaultConnectorInfo = {
 name: "unknown",
 type: "unknown",
 color: "",
 class: "",
 docs: "unknown.html"
};

/**
 * dirPagination - AngularJS module for paginating (almost) anything.
 *
 *
 * Credits
 * =======
 *
 * Daniel Tabuenca: https://groups.google.com/d/msg/angular/an9QpzqIYiM/r8v-3W1X5vcJ
 * for the idea on how to dynamically invoke the ng-repeat directive.
 *
 * I borrowed a couple of lines and a few attribute names from the AngularUI Bootstrap project:
 * https://github.com/angular-ui/bootstrap/blob/master/src/pagination/pagination.js
 *
 * Copyright 2014 Michael Bromley <michael@michaelbromley.co.uk>
 *
 * @antonios 18-Aug-16 enhanced this with a material-design pagination template
 */

(function () {

  /**
   * Config
   */
  var moduleName = 'angularUtils.directives.dirPagination';
  var DEFAULT_ID = '__default';

  /**
   * Module
   */
  angular.module(moduleName, [])
    .directive('dirPaginate', ['$compile', '$parse', 'paginationService', dirPaginateDirective])
    .directive('dirPaginateNoCompile', noCompileDirective)
    .directive('dirPaginationControls', ['paginationService', 'paginationTemplate', dirPaginationControlsDirective])
    .filter('itemsPerPage', ['paginationService', itemsPerPageFilter])
    .service('paginationService', paginationService)
    .provider('paginationTemplate', paginationTemplateProvider)
    .run(['$templateCache', dirPaginationControlsTemplateInstaller]);

  function dirPaginateDirective($compile, $parse, paginationService) {

    return {
      terminal: true,
      multiElement: true,
      priority: 100,
      compile: dirPaginationCompileFn
    };

    function dirPaginationCompileFn(tElement, tAttrs) {

      var expression = tAttrs.dirPaginate;
      // regex taken directly from https://github.com/angular/angular.js/blob/v1.4.x/src/ng/directive/ngRepeat.js#L339
      var match = expression.match(/^\s*([\s\S]+?)\s+in\s+([\s\S]+?)(?:\s+as\s+([\s\S]+?))?(?:\s+track\s+by\s+([\s\S]+?))?\s*$/);

      var filterPattern = /\|\s*itemsPerPage\s*:\s*(.*\(\s*\w*\)|([^\)]*?(?=\s+as\s+))|[^\)]*)/;
      if (match[2].match(filterPattern) === null) {
        throw 'pagination directive: the \'itemsPerPage\' filter must be set.';
      }
      var itemsPerPageFilterRemoved = match[2].replace(filterPattern, '');
      var collectionGetter = $parse(itemsPerPageFilterRemoved);

      addNoCompileAttributes(tElement);

      // If any value is specified for paginationId, we register the un-evaluated expression at this stage for the benefit of any
      // dir-pagination-controls directives that may be looking for this ID.
      var rawId = tAttrs.paginationId || DEFAULT_ID;
      paginationService.registerInstance(rawId);

      return function dirPaginationLinkFn(scope, element, attrs) {

        // Now that we have access to the `scope` we can interpolate any expression given in the paginationId attribute and
        // potentially register a new ID if it evaluates to a different value than the rawId.
        var paginationId = $parse(attrs.paginationId)(scope) || attrs.paginationId || DEFAULT_ID;

        // (TODO: this seems sound, but I'm reverting as many bug reports followed it's introduction in 0.11.0.
        // Needs more investigation.)
        // In case rawId != paginationId we deregister using rawId for the sake of general cleanliness
        // before registering using paginationId
        // paginationService.deregisterInstance(rawId);
        paginationService.registerInstance(paginationId);

        var repeatExpression = getRepeatExpression(expression, paginationId);
        addNgRepeatToElement(element, attrs, repeatExpression);

        removeTemporaryAttributes(element);
        var compiled = $compile(element);

        var currentPageGetter = makeCurrentPageGetterFn(scope, attrs, paginationId);
        paginationService.setCurrentPageParser(paginationId, currentPageGetter, scope);

        if (typeof attrs.totalItems !== 'undefined') {
          paginationService.setAsyncModeTrue(paginationId);
          scope.$watch(function () {
            return $parse(attrs.totalItems)(scope);
          }, function (result) {
            if (0 <= result) {
              paginationService.setCollectionLength(paginationId, result);
            }
          });
        } else {
          paginationService.setAsyncModeFalse(paginationId);
          scope.$watchCollection(function () {
            return collectionGetter(scope);
          }, function (collection) {
            if (collection) {
              var collectionLength = (collection instanceof Array) ? collection.length : Object.keys(collection).length;
              paginationService.setCollectionLength(paginationId, collectionLength);
            }
          });
        }

        // Delegate to the link function returned by the new compilation of the ng-repeat
        compiled(scope);

        // (TODO: Reverting this due to many bug reports in v 0.11.0. Needs investigation as the
        // principle is sound)
        // When the scope is destroyed, we make sure to remove the reference to it in paginationService
        // so that it can be properly garbage collected
        // scope.$on('$destroy', function destroyDirPagination() {
        //     paginationService.deregisterInstance(paginationId);
        // });
      };
    }

    /**
     * If a pagination id has been specified, we need to check that it is present as the second argument passed to
     * the itemsPerPage filter. If it is not there, we add it and return the modified expression.
     *
     * @param expression
     * @param paginationId
     * @returns {*}
     */
    function getRepeatExpression(expression, paginationId) {
      var repeatExpression,
        idDefinedInFilter = !!expression.match(/(\|\s*itemsPerPage\s*:[^|]*:[^|]*)/);

      if (paginationId !== DEFAULT_ID && !idDefinedInFilter) {
        repeatExpression = expression.replace(/(\|\s*itemsPerPage\s*:\s*[^|\s]*)/, "$1 : '" + paginationId + "'");
      } else {
        repeatExpression = expression;
      }

      return repeatExpression;
    }

    /**
     * Adds the ng-repeat directive to the element. In the case of multi-element (-start, -end) it adds the
     * appropriate multi-element ng-repeat to the first and last element in the range.
     * @param element
     * @param attrs
     * @param repeatExpression
     */
    function addNgRepeatToElement(element, attrs, repeatExpression) {
      if (element[0].hasAttribute('dir-paginate-start') || element[0].hasAttribute('data-dir-paginate-start')) {
        // using multiElement mode (dir-paginate-start, dir-paginate-end)
        attrs.$set('ngRepeatStart', repeatExpression);
        element.eq(element.length - 1).attr('ng-repeat-end', true);
      } else {
        attrs.$set('ngRepeat', repeatExpression);
      }
    }

    /**
     * Adds the dir-paginate-no-compile directive to each element in the tElement range.
     * @param tElement
     */
    function addNoCompileAttributes(tElement) {
      angular.forEach(tElement, function (el) {
        if (el.nodeType === 1) {
          angular.element(el).attr('dir-paginate-no-compile', true);
        }
      });
    }

    /**
     * Removes the variations on dir-paginate (data-, -start, -end) and the dir-paginate-no-compile directives.
     * @param element
     */
    function removeTemporaryAttributes(element) {
      angular.forEach(element, function (el) {
        if (el.nodeType === 1) {
          angular.element(el).removeAttr('dir-paginate-no-compile');
        }
      });
      element.eq(0).removeAttr('dir-paginate-start').removeAttr('dir-paginate').removeAttr('data-dir-paginate-start').removeAttr('data-dir-paginate');
      element.eq(element.length - 1).removeAttr('dir-paginate-end').removeAttr('data-dir-paginate-end');
    }

    /**
     * Creates a getter function for the current-page attribute, using the expression provided or a default value if
     * no current-page expression was specified.
     *
     * @param scope
     * @param attrs
     * @param paginationId
     * @returns {*}
     */
    function makeCurrentPageGetterFn(scope, attrs, paginationId) {
      var currentPageGetter;
      if (attrs.currentPage) {
        currentPageGetter = $parse(attrs.currentPage);
      } else {
        // If the current-page attribute was not set, we'll make our own.
        // Replace any non-alphanumeric characters which might confuse
        // the $parse service and give unexpected results.
        // See https://github.com/michaelbromley/angularUtils/issues/233
        var defaultCurrentPage = (paginationId + '__currentPage').replace(/\W/g, '_');
        scope[defaultCurrentPage] = 1;
        currentPageGetter = $parse(defaultCurrentPage);
      }
      return currentPageGetter;
    }
  }

  /**
   * This is a helper directive that allows correct compilation when in multi-element mode (ie dir-paginate-start, dir-paginate-end).
   * It is dynamically added to all elements in the dir-paginate compile function, and it prevents further compilation of
   * any inner directives. It is then removed in the link function, and all inner directives are then manually compiled.
   */
  function noCompileDirective() {
    return {
      priority: 5000,
      terminal: true
    };
  }

  function dirPaginationControlsTemplateInstaller($templateCache) {
    var strVar = "";
    strVar += "<section style=\"margin: 5px 10px 0;\" layout=\"row\" layout-align=\"center\" ng-if=\"1 < pages.length || !autoHide\" class=\"pagination\"> <md-button aria-label=\"Previous page\" ng-if=\"boundaryLinks\" ng-disabled=\"pagination.current===1\" ng-click=\"setCurrent(1)\"> <ng-md-icon icon=\"first_page\"><\/ng-md-icon> <\/md-button> <md-button aria-label=\"First page\" ng-if=\"directionLinks\" ng-disabled=\"pagination.current===1\" ng-click=\"setCurrent(pagination.current - 1)\"> <ng-md-icon class=\"fa fa-chevron-left\"><\/ng-md-icon> <\/md-button> <md-button ng-repeat=\"pageNumber in pages track by tracker(pageNumber, $index)\" ng-class=\"{'md-primary' : pagination.current==pageNumber}\" ng-disabled=\"pageNumber==='...'\" ng-click=\"setCurrent(pageNumber)\">{{pageNumber}}<\/md-button> <md-button aria-label=\"Last page\" ng-if=\"directionLinks\" ng-disabled=\"pagination.current===pagination.last\" ng-click=\"setCurrent(pagination.current + 1)\"> <ng-md-icon class=\"fa fa-chevron-right\"><\/ng-md-icon> <\/md-button> <md-button ng-if=\"boundaryLinks\" ng-disabled=\"pagination.current===pagination.last\" ng-click=\"setCurrent(pagination.last)\"> <ng-md-icon icon=\"last_page\"><\/ng-md-icon> <\/md-button><\/section>";

    $templateCache.put('angularUtils.directives.dirPagination.template', strVar);
  }

  function dirPaginationControlsDirective(paginationService, paginationTemplate) {

    var numberRegex = /^\d+$/;

    var DDO = {
      restrict: 'AE',
      scope: {
        maxSize: '=?',
        onPageChange: '&?',
        paginationId: '=?',
        autoHide: '=?'
      },
      link: dirPaginationControlsLinkFn
    };

    // We need to check the paginationTemplate service to see whether a template path or
    // string has been specified, and add the `template` or `templateUrl` property to
    // the DDO as appropriate. The order of priority to decide which template to use is
    // (highest priority first):
    // 1. paginationTemplate.getString()
    // 2. attrs.templateUrl
    // 3. paginationTemplate.getPath()
    var templateString = paginationTemplate.getString();
    if (templateString !== undefined) {
      DDO.template = templateString;
    } else {
      DDO.templateUrl = function (elem, attrs) {
        return attrs.templateUrl || paginationTemplate.getPath();
      };
    }
    return DDO;

    function dirPaginationControlsLinkFn(scope, element, attrs) {

      // rawId is the un-interpolated value of the pagination-id attribute. This is only important when the corresponding dir-paginate directive has
      // not yet been linked (e.g. if it is inside an ng-if block), and in that case it prevents this controls directive from assuming that there is
      // no corresponding dir-paginate directive and wrongly throwing an exception.
      var rawId = attrs.paginationId || DEFAULT_ID;
      var paginationId = scope.paginationId || attrs.paginationId || DEFAULT_ID;

      if (!paginationService.isRegistered(paginationId) && !paginationService.isRegistered(rawId)) {
        var idMessage = (paginationId !== DEFAULT_ID) ? ' (id: ' + paginationId + ') ' : ' ';
        if (window.console) {
          console.warn('Pagination directive: the pagination controls' + idMessage + 'cannot be used without the corresponding pagination directive, which was not found at link time.');
        }
      }

      if (!scope.maxSize) {
        scope.maxSize = 9;
      }
      scope.autoHide = scope.autoHide === undefined ? true : scope.autoHide;
      scope.directionLinks = angular.isDefined(attrs.directionLinks) ? scope.$parent.$eval(attrs.directionLinks) : true;
      scope.boundaryLinks = angular.isDefined(attrs.boundaryLinks) ? scope.$parent.$eval(attrs.boundaryLinks) : false;

      var paginationRange = Math.max(scope.maxSize, 5);
      scope.pages = [];
      scope.pagination = {
        last: 1,
        current: 1
      };
      scope.range = {
        lower: 1,
        upper: 1,
        total: 1
      };

      scope.$watch('maxSize', function (val) {
        if (val) {
          paginationRange = Math.max(scope.maxSize, 5);
          generatePagination();
        }
      });

      scope.$watch(function () {
        if (paginationService.isRegistered(paginationId)) {
          return (paginationService.getCollectionLength(paginationId) + 1) * paginationService.getItemsPerPage(paginationId);
        }
      }, function (length) {
        if (0 < length) {
          generatePagination();
        }
      });

      scope.$watch(function () {
        if (paginationService.isRegistered(paginationId)) {
          return (paginationService.getItemsPerPage(paginationId));
        }
      }, function (current, previous) {
        if (current != previous && typeof previous !== 'undefined') {
          goToPage(scope.pagination.current);
        }
      });

      scope.$watch(function () {
        if (paginationService.isRegistered(paginationId)) {
          return paginationService.getCurrentPage(paginationId);
        }
      }, function (currentPage, previousPage) {
        if (currentPage != previousPage) {
          goToPage(currentPage);
        }
      });

      scope.setCurrent = function (num) {
        if (paginationService.isRegistered(paginationId) && isValidPageNumber(num)) {
          num = parseInt(num, 10);
          paginationService.setCurrentPage(paginationId, num);
        }
      };

      /**
       * Custom "track by" function which allows for duplicate "..." entries on long lists,
       * yet fixes the problem of wrongly-highlighted links which happens when using
       * "track by $index" - see https://github.com/michaelbromley/angularUtils/issues/153
       * @param id
       * @param index
       * @returns {string}
       */
      scope.tracker = function (id, index) {
        return id + '_' + index;
      };

      function goToPage(num) {
        if (paginationService.isRegistered(paginationId) && isValidPageNumber(num)) {
          var oldPageNumber = scope.pagination.current;

          scope.pages = generatePagesArray(num, paginationService.getCollectionLength(paginationId), paginationService.getItemsPerPage(paginationId), paginationRange);
          scope.pagination.current = num;
          updateRangeValues();

          // if a callback has been set, then call it with the page number as the first argument
          // and the previous page number as a second argument
          if (scope.onPageChange) {
            scope.onPageChange({
              newPageNumber: num,
              oldPageNumber: oldPageNumber
            });
          }
        }
      }

      function generatePagination() {
        if (paginationService.isRegistered(paginationId)) {
          var page = parseInt(paginationService.getCurrentPage(paginationId)) || 1;
          scope.pages = generatePagesArray(page, paginationService.getCollectionLength(paginationId), paginationService.getItemsPerPage(paginationId), paginationRange);
          scope.pagination.current = page;
          scope.pagination.last = scope.pages[scope.pages.length - 1];
          if (scope.pagination.last < scope.pagination.current) {
            scope.setCurrent(scope.pagination.last);
          } else {
            updateRangeValues();
          }
        }
      }

      /**
       * This function updates the values (lower, upper, total) of the `scope.range` object, which can be used in the pagination
       * template to display the current page range, e.g. "showing 21 - 40 of 144 results";
       */
      function updateRangeValues() {
        if (paginationService.isRegistered(paginationId)) {
          var currentPage = paginationService.getCurrentPage(paginationId),
            itemsPerPage = paginationService.getItemsPerPage(paginationId),
            totalItems = paginationService.getCollectionLength(paginationId);

          scope.range.lower = (currentPage - 1) * itemsPerPage + 1;
          scope.range.upper = Math.min(currentPage * itemsPerPage, totalItems);
          scope.range.total = totalItems;
        }
      }

      function isValidPageNumber(num) {
        return (numberRegex.test(num) && (0 < num && num <= scope.pagination.last));
      }
    }

    /**
     * Generate an array of page numbers (or the '...' string) which is used in an ng-repeat to generate the
     * links used in pagination
     *
     * @param currentPage
     * @param rowsPerPage
     * @param paginationRange
     * @param collectionLength
     * @returns {Array}
     */
    function generatePagesArray(currentPage, collectionLength, rowsPerPage, paginationRange) {
      var pages = [];
      var totalPages = Math.ceil(collectionLength / rowsPerPage);
      var halfWay = Math.ceil(paginationRange / 2);
      var position;

      if (currentPage <= halfWay) {
        position = 'start';
      } else if (totalPages - halfWay < currentPage) {
        position = 'end';
      } else {
        position = 'middle';
      }

      var ellipsesNeeded = paginationRange < totalPages;
      var i = 1;
      while (i <= totalPages && i <= paginationRange) {
        var pageNumber = calculatePageNumber(i, currentPage, paginationRange, totalPages);

        var openingEllipsesNeeded = (i === 2 && (position === 'middle' || position === 'end'));
        var closingEllipsesNeeded = (i === paginationRange - 1 && (position === 'middle' || position === 'start'));
        if (ellipsesNeeded && (openingEllipsesNeeded || closingEllipsesNeeded)) {
          pages.push('...');
        } else {
          pages.push(pageNumber);
        }
        i++;
      }
      return pages;
    }

    /**
     * Given the position in the sequence of pagination links [i], figure out what page number corresponds to that position.
     *
     * @param i
     * @param currentPage
     * @param paginationRange
     * @param totalPages
     * @returns {*}
     */
    function calculatePageNumber(i, currentPage, paginationRange, totalPages) {
      var halfWay = Math.ceil(paginationRange / 2);
      if (i === paginationRange) {
        return totalPages;
      } else if (i === 1) {
        return i;
      } else if (paginationRange < totalPages) {
        if (totalPages - halfWay < currentPage) {
          return totalPages - paginationRange + i;
        } else if (halfWay < currentPage) {
          return currentPage - halfWay + i;
        } else {
          return i;
        }
      } else {
        return i;
      }
    }
  }

  /**
   * This filter slices the collection into pages based on the current page number and number of items per page.
   * @param paginationService
   * @returns {Function}
   */
  function itemsPerPageFilter(paginationService) {

    return function (collection, itemsPerPage, paginationId) {
      if (typeof (paginationId) === 'undefined') {
        paginationId = DEFAULT_ID;
      }
      if (!paginationService.isRegistered(paginationId)) {
        throw 'pagination directive: the itemsPerPage id argument (id: ' + paginationId + ') does not match a registered pagination-id.';
      }
      var end;
      var start;
      if (angular.isObject(collection)) {
        itemsPerPage = parseInt(itemsPerPage) || 9999999999;
        if (paginationService.isAsyncMode(paginationId)) {
          start = 0;
        } else {
          start = (paginationService.getCurrentPage(paginationId) - 1) * itemsPerPage;
        }
        end = start + itemsPerPage;
        paginationService.setItemsPerPage(paginationId, itemsPerPage);

        if (collection instanceof Array) {
          // the array just needs to be sliced
          return collection.slice(start, end);
        } else {
          // in the case of an object, we need to get an array of keys, slice that, then map back to
          // the original object.
          var slicedObject = {};
          angular.forEach(keys(collection).slice(start, end), function (key) {
            slicedObject[key] = collection[key];
          });
          return slicedObject;
        }
      } else {
        return collection;
      }
    };
  }

  /**
   * Shim for the Object.keys() method which does not exist in IE < 9
   * @param obj
   * @returns {Array}
   */
  function keys(obj) {
    if (!Object.keys) {
      var objKeys = [];
      for (var i in obj) {
        if (obj.hasOwnProperty(i)) {
          objKeys.push(i);
        }
      }
      return objKeys;
    } else {
      return Object.keys(obj);
    }
  }

  /**
   * This service allows the various parts of the module to communicate and stay in sync.
   */
  function paginationService() {

    var instances = {};
    var lastRegisteredInstance;

    this.registerInstance = function (instanceId) {
      if (typeof instances[instanceId] === 'undefined') {
        instances[instanceId] = {
          asyncMode: false
        };
        lastRegisteredInstance = instanceId;
      }
    };

    this.deregisterInstance = function (instanceId) {
      delete instances[instanceId];
    };

    this.isRegistered = function (instanceId) {
      return (typeof instances[instanceId] !== 'undefined');
    };

    this.getLastInstanceId = function () {
      return lastRegisteredInstance;
    };

    this.setCurrentPageParser = function (instanceId, val, scope) {
      instances[instanceId].currentPageParser = val;
      instances[instanceId].context = scope;
    };
    this.setCurrentPage = function (instanceId, val) {
      instances[instanceId].currentPageParser.assign(instances[instanceId].context, val);
    };
    this.getCurrentPage = function (instanceId) {
      var parser = instances[instanceId].currentPageParser;
      return parser ? parser(instances[instanceId].context) : 1;
    };

    this.setItemsPerPage = function (instanceId, val) {
      instances[instanceId].itemsPerPage = val;
    };
    this.getItemsPerPage = function (instanceId) {
      return instances[instanceId].itemsPerPage;
    };

    this.setCollectionLength = function (instanceId, val) {
      instances[instanceId].collectionLength = val;
    };
    this.getCollectionLength = function (instanceId) {
      return instances[instanceId].collectionLength;
    };

    this.setAsyncModeTrue = function (instanceId) {
      instances[instanceId].asyncMode = true;
    };

    this.setAsyncModeFalse = function (instanceId) {
      instances[instanceId].asyncMode = false;
    };

    this.isAsyncMode = function (instanceId) {
      return instances[instanceId].asyncMode;
    };
  }

  /**
   * This provider allows global configuration of the template path used by the dir-pagination-controls directive.
   */
  function paginationTemplateProvider() {

    var templatePath = 'angularUtils.directives.dirPagination.template';
    var templateString;

    /**
     * Set a templateUrl to be used by all instances of <dir-pagination-controls>
     * @param {String} path
     */
    this.setPath = function (path) {
      templatePath = path;
    };

    /**
     * Set a string of HTML to be used as a template by all instances
     * of <dir-pagination-controls>. If both a path *and* a string have been set,
     * the string takes precedence.
     * @param {String} str
     */
    this.setString = function (str) {
      templateString = str;
    };

    this.$get = function () {
      return {
        getPath: function () {
          return templatePath;
        },
        getString: function () {
          return templateString;
        }
      };
    };
  }
})();

'use strict';

var angularAPP = angular.module('angularAPP', [
  'ui.ace',
  'angularUtils.directives.dirPagination',
  'ngRoute',
  'ngMaterial',
  'ngAnimate',
  'ngAria',
  'ng',
  'ngMessages',
  'googlechart'
]);

angularAPP.controller('HeaderCtrl', function ($rootScope, $scope, $location, env) {


  $scope.$on('$routeChangeSuccess', function() {
     $rootScope.clusters = env.getClusters();
     $scope.cluster = env.getSelectedCluster();
     $scope.color = $scope.cluster.COLOR;
  });

  $scope.updateEndPoint = function(cluster) {
    $rootScope.connectionFailure = false;
    $location.path("/cluster/"+cluster)
  }
});

angularAPP.run(
    function loadRoute( env, $routeParams, $rootScope ) {
        $rootScope.$on('$routeChangeSuccess', function() {
          $rootScope.isHome = false;
          env.setSelectedCluster($routeParams.cluster);
       });
    }
)

/* Routing */

angularAPP.config(function ($routeProvider) {
  $routeProvider
    .when('/', {
      templateUrl: 'src/kafka-connect/home/home.html',
       controller: 'HomeCtrl'
    })
    .when('/cluster/:cluster', {
      templateUrl: 'src/kafka-connect/cluster-view/cluster-view.html',
       controller: 'ClusterViewCtrl'
    })
    .when('/cluster/:cluster/select-connector', {
      templateUrl: 'src/kafka-connect/select-type/sink-or-source.html',
      controller: 'SelectNewConnectorCtrl'
    })
    .when('/cluster/:cluster/create-connector/:className', {
      templateUrl: 'src/kafka-connect/create-connector/create-connector.html',
      controller: 'CreateConnectorCtrl'
    })
    .when('/cluster/:cluster/export-configs', {
      templateUrl: 'src/kafka-connect/export-configs/export-configs.html',
      controller: 'ExportConfigsCtrl'
    })
    .when('/cluster/:cluster/connector/:runningConnector', {
      templateUrl: 'src/kafka-connect/view/connector-view.html',
      controller: 'ConnectorDetailCtrl'
    }).otherwise({
    redirectTo: '/'
  });

});

/* App Config */

angularAPP.config(function ($mdThemingProvider, $httpProvider, $provide) {

 $httpProvider.interceptors.push('myHttpInterceptor');

 $mdThemingProvider.theme('default')
                   .primaryPalette('blue-grey')
                   .accentPalette('blue')
                   .warnPalette('grey');
});

angularAPP.config(['$compileProvider',
    function ($compileProvider) {
        $compileProvider.aHrefSanitizationWhitelist(/^\s*(https?|ftp|mailto|tel|file|blob):/);
}]);

/* Google chart config */
angularAPP.value('googleChartApiConfig', {
  version: '1.1',
  optionalSettings: {
    packages: ['sankey'] //load just the package you want
  }
});

/* Custom directives */

angularAPP.directive('validJson', function() {
  return {
    require: 'ngModel',
    priority: 1000,
    link: function(scope, elem, attrs, ngModel) {

      // view to model
      ngModel.$parsers.unshift(function(value) {
        var valid = true,
          obj;
        try {
          obj = JSON.parse(value);
        } catch (ex) {
          valid = false;
        }
        ngModel.$setValidity('validJson', valid);
        return valid ? obj : undefined;
      });

      // model to view
      ngModel.$formatters.push(function(value) {
        return value;//JSON.stringify(value, null, '\t');
      });
    }
  };
});

/*
 * This directive runs on the 'name' input and checks if the name of the controller provided is unique.
 */
angularAPP.directive('uniqueControllerName', function(KafkaConnectFactory) {
  return {
    require : 'ngModel',
    link : function(scope, element, attrs, ngModel) {

         //Initially set the validity, so next button is disabled
        if(attrs.uniqueControllerName == 'name') {
          KafkaConnectFactory.getConnectors(true).then (function(connectors){
            scope.connectorNames = connectors
            scope.existsInit = scope.connectorNames.indexOf(scope.element.value) !== -1
            ngModel.$setValidity('unique', !scope.existsInit );
          });

          //As the user types
          ngModel.$parsers.push(function(value) {
              var exists = scope.connectorNames.indexOf(value) !== -1; //why exists doesnt work??
              ngModel.$setValidity('unique', !exists );
              return value;
          });

        }
    }
  }
});

// html filter (render text as html)
angularAPP.filter('html', ['$sce', function ($sce) {
    return function (text) {
        return $sce.trustAsHtml(text);
    };
}])

angularAPP.factory('NewConnectorFactory', function (supportedConnectorsFactory, $log, $rootScope, env, $filter) {


  /* Public API */
  return {

    initConnector : function (name) {
        var con = supportedConnectorsFactory.getSupportedConnector().filter(supportedConnectorsFactory.matchesName(name))[0];
        if (con != undefined) {
          return angular.copy(con);
        } else
        return undefined
    },

    flattenConnectorKeyValues: function (connector) {
       //3 nested lists: Steps -> Sections -> Elements
          var sectionsPerStep = connector.template.map(function (step) {
              var sections = step.sections.map(function (section) {
                  return section.elements.map(function (element) {
                      return element.key + '=' + element.value;// + '\n';
                  })
               });
               return [].concat.apply([], sections); //All sections flatten
           });
          return [].concat.apply([], sectionsPerStep); //All steps flatten;
    },

    //TODO how it returns??
    updateConnectorFromModelValues: function(flattenValues, connector) {
       angular.forEach(flattenValues, function(item) {
          var keyValue = item.split('=');
          var sectionsPerStep = connector.template.map(function (step) {
               return step.sections.map(function (section) {
                   return section.elements.map(function (element) {
                        if(keyValue[0] == element.key) {
                          if(parseInt(keyValue[1])) element.value = parseInt(keyValue[1]);
                          else element.value=keyValue[1];
                        }
                  })
               });
           });
       });
    },

    getCurlCommand: function (configValues) {
          var connectorCurlObject = makeConfigFromConfigValuesArray(configValues);
          delete connectorCurlObject.config.name;
          return prepareCurlCommandString(connectorCurlObject);
    },

    getJSONConfig: function (configValues) {
          var connectorCurlObject = makeConfigFromConfigValuesArray(configValues);
          delete connectorCurlObject.config.name;
          return connectorCurlObject;
    },

    getJSONConfigFlat : function (configValues) {
          return makeConfigFromConfigValuesArray(configValues).config;
    },

    //Not in use
    emptyValues: function(connector) {
       var steps = connector.template.map(function (step) {
             return step.sections.map(function (section) {
               section.elements.map(function (element) {
                    element.value = '';
                    return element;
                });
                return section;
             });
         });
         connector.template = steps;
         return connector;
    }

  };

  /* Private Methods */

  function prepareCurlCommandString(curlCommandObj) {
      var prefix = "cat << EOF > " + curlCommandObj.name + ".json" + "\n";
      var content = angular.toJson(curlCommandObj, true);
      var suffix = "\n" + "EOF" +
                   "\n" + 'curl -X POST -H "Content-Type: application/json" -H "Accept: application/json" -d @' +
                   curlCommandObj.name + '.json ' +
                   env.KAFKA_CONNECT() + '/connectors';
      return prefix + content + suffix;
  }

  /**
   *  This function includes `name` in the config object. TODO Do we need it?
   **/
  function makeConfigFromConfigValuesArray(configValues) {
      var connectorCurlObject = {
           name: "",
           config: {}
      };

       angular.forEach(configValues, function (propertyLine) {
         if (propertyLine.length > 2) {
           var key = propertyLine.substring(0, propertyLine.indexOf('='));
           var value = propertyLine.substring(propertyLine.indexOf('=') + 1);
           connectorCurlObject.config["" + key] = value;
         }
       });

       connectorCurlObject.name = connectorCurlObject.config.name;
       return connectorCurlObject;
  }

});
angularAPP.factory('connectorObjects', function (KafkaConnectFactory, supportedConnectorsFactory, $q, $rootScope) {


    return {
       getConnectorList : function () {
            return KafkaConnectFactory.getConnectors(true).then(function successCallback(connectors) {
                  return enhanceConnectors(connectors);
            });
       },
       getConnector : function (connectorName) {
           return KafkaConnectFactory.getConnectorInfo(connectorName).then(function successCallback(connector) {
               return enhanceConnector(connector);
          });
       },
       getTopics : function(connectorConfig) {
           return extractTopicsFromConfig(connectorConfig);
       },
       getConnectorTemplate : function(connectorConfig) {
           return supportedConnectorsFactory.getSupportedConnectorObj(connectorConfig["connector.class"]);
       }

    };

    function enhanceConnector(connector, isList) {

        var enhancedConnector;
        var connectorName = connector.name;
        var connectorConfig = connector.config;
        var connectorUiInfo = supportedConnectorsFactory.getSupportedConnectorObj(connectorConfig["connector.class"]);
        var connectorStatus = getConnectorStatus(connectorName);

        if(isList) {
            enhancedConnector =  {
                name: connectorName,
                isSource: isSource(connector),
                type: connectorUiInfo.name,
                color: connectorUiInfo.color,
                connectorState: connectorStatus.connector,// getConnectorStatus(connectorName),
                tasks: connectorStatus.tasks,
                workers: connectorConfig["tasks.max"]
            };
        } else { //Is detail
            enhancedConnector =  {
                name: connectorName,
                config: connectorConfig,
                isSource: isSource(connector),
                type: connectorUiInfo.name,
                color: connectorUiInfo.color,
                connectorState: connectorStatus.connector,//getConnectorStatus(connectorName),
                topics: extractTopicsFromConfig(connectorConfig),
                workers: connectorConfig["tasks.max"],
                tasks: connectorStatus.tasks,//getTaskStatus(connectorName).tasks,
                detailedTasks: getTaskDetails(connectorName),
                connectorDetailsInString : angular.toJson(connectorConfig, true),
                supportedConnectorTemplate : connectorUiInfo
            };
        }
        return enhancedConnector;
      }

      function isSource(connector) {
        var connectorUiInfo = supportedConnectorsFactory.getSupportedConnectorObj(connector.config["connector.class"]);
        if (connectorUiInfo.type != '')
          return (connectorUiInfo.type == 'Source')
          else {
            var isSource='';
            var a = connector.config["connector.class"].split('.');
            if (a[a.length-1].toLowerCase().indexOf('sink') > 0) {
              isSource=false;
            } else if (a[a.length-1].toLowerCase().indexOf('source') > 0) {
              isSource=true;
            }
          return isSource
          }
      }

      function enhanceConnectors(connectors) {
          var allConnectorsWithMetadata = [];
          angular.forEach(connectors, function(connectorName) {
              KafkaConnectFactory.getConnectorInfo(connectorName)
                 .then( function successCallback(connectorInfo) {
                     return enhanceConnector(connectorInfo, true);
                 })
                 .then(function successCallback(enhancedConnector){
                      return allConnectorsWithMetadata.push(enhancedConnector);
                 })
          })
         return allConnectorsWithMetadata;
      }

      function extractTopicsFromConfig(connectorConfig) {
        var topics = [];
        angular.forEach(connectorConfig, function (value, key) {
            // adding extra logic to capture information about FTP Source connectors
            if (key.indexOf("connect.ftp.monitor") != -1) {
                var setup = value.split(": ");
                topics.push(setup)
            }
            if (key.indexOf("topic") != -1) {
              if( key !== 'connect.jms.sink.export.route.topics' ) { // hardcoded exclude of this jms sink key
                var tArray = value.split(",");
                if(tArray.length > 1) {
                  angular.forEach(tArray, function (t) {
                    topics.push(t)
                  })
                } else {
                  topics.push(value);
                }
              }
            }
        });
        return topics;
      }

      function getTaskDetails(connectorName) {
         var itemArray = [];
         KafkaConnectFactory.getConnectorTasks(connectorName).then(
          function success(items) {
             angular.forEach(items, function (item) {
                 itemArray.push(item);
              });
         });
        return itemArray;
      }

      function getConnectorStatus(connectorName) {
          var tasks=[];
          var statuses = {};
          var status = {
              tasks : {},
              connector : {}
              };

          KafkaConnectFactory.getConnectorStatus(connectorName).then( function success(data) { //We get the taks details from status
            statuses[connectorName] = data.data.connector.state;
            angular.forEach(data.data.tasks, function (task) {
                tasks.push(task);
            });
          });

          status.tasks = tasks;
          status.connector = statuses;
          return status;

       }

       //      function getConnectorStatus(connectorName, isList) {
       //        var statuses = {};
       //        KafkaConnectFactory.getConnectorStatus(connectorName).then(function(data) {
       //                statuses[connectorName] = data.data.connector.state;
       //         })
       //         return statuses;
       //      }
       //
       //      function getTaskStatus(connectorName) {
       //          var tasks=[];
       //          var status = { tasks : {} };
       //          KafkaConnectFactory.getConnectorStatus(connectorName).then( function success(status) {
       //            angular.forEach(status.data.tasks, function (task) {
       //                tasks.push(task);
       //            });
       //          });
       //          status.tasks = tasks;
       //          return status;
       //      }

});
angularAPP.factory('constants', function () {

  return {
    MESSAGE_REBALANCING : "Rebalancing won’t take more than 2 minutes, please wait.",
    MESSAGE_WELCOME : "Dashboard",

    CONFIG_CONNECTIVITY_ERROR : "CONNECTIVITY ERROR",

    LIST_NO_CONNECTORS_FOUND : "No connectors found",

    VIEW_MESSAGE_CONNECTOR_VALID: "Kafka Connect: Configuration is valid.",
    VIEW_EDITOR_INVALID_SYNTAX : "Invalid syntax"
  }
});

angularAPP.factory('env', function ($rootScope) {

//  var ENV = clusters; //TODO if empty env.js

  var clusterArray = (typeof clusters !== "undefined") ? angular.copy(clusters) : [];
  var selectedCluster = null;
  setCluster();

  return {
    setSelectedCluster : function(clusterName) { setCluster(clusterName)},
    getSelectedCluster : function() { return selectedCluster; },
    getClusters : function() { return clusters} ,

    KAFKA_REST : function () { return selectedCluster.KAFKA_REST; },
    KAFKA_CONNECT : function () { return selectedCluster.KAFKA_CONNECT; },
    KAFKA_TOPICS_UI : function () { return selectedCluster.KAFKA_TOPICS_UI; },
    KAFKA_TOPICS_UI_ENABLED :  function () { return selectedCluster.KAFKA_TOPICS_UI_ENABLED; },

    enableInterceptorLogs : false,
  }

  function setCluster(clusterName) {
    if(clusterArray.length == 0) {
        $rootScope.missingEnvJS = true;
              console.log("NOT EXISTS env.js")
     }
     if(angular.isUndefined(clusterName)) {
          selectedCluster = clusterArray[0];
     } else {
          var filteredArray = clusterArray.filter(function(el) {return el.NAME == clusterName})
          selectedCluster = filteredArray.length == 1 ?  filteredArray[0]  : clusterArray[0]
     }
  }
});
angularAPP.factory('myHttpInterceptor', function($q, $injector, $log, $rootScope, env) {
    var pendingRequests = [];
    var incrementalTimeout = 1000;
    var start;

    /* Public Api */

    return {
      'request': function(request) {
        start = new Date().getTime();
        $rootScope.configValidationMessage = "";
        pendingRequests.push(request.url);
        return request;
      },

     'requestError': function(rejection) {
        return $q.reject(rejection);
      },

      'response': function(response) {
         if(response.config.url.indexOf(env.KAFKA_CONNECT() == 0) && env.enableInterceptorLogs) {
            $log.debug("  curl -X  " + response.config.method + " " + response.config.url + " in [ " + (new Date().getTime() - start) + " ] msec");
            $log.info (response)
         }
         var index = pendingRequests.indexOf(response.config.url);
         // Remove from queue
         if (index !== -1) {
           pendingRequests.splice(index, 1);
         }

         if (pendingRequests.length == 0)
           $rootScope.rebalancing = false;

        return response;
      },
     'responseError': function(response) {
        if (response.status === -1 && response.data == null || response.status === 502){
            $rootScope.rebalancing = false;
            $rootScope.connectionFailure = true;
        } else if (response.status === 409 || response.status === 504) {
            $rootScope.loading = true;
            if(response.status === 409) {
                $log.error("409 - cluster rebalance or restart is in process.")
                $rootScope.rebalancing = true;
                $rootScope.connectionFailure = false;
            }
            return retryRequest(response.config);
        } else {
            incrementalTimeout = 1000;
            $rootScope.configValidationMessage = 'An error occured with status code ' + response.status + ' : ' + response.statusText;
        }
        return $q.reject(response);
      }
    };

    /* Private Methods */

    function retryRequest (httpConfig) {
        $log.info("Retrying request... " + JSON.stringify(httpConfig))
        var $timeout = $injector.get('$timeout');

        return $timeout(function() {
            var $http = $injector.get('$http');
            return $http(httpConfig);
        }, incrementalTimeout);

        incrementalTimeout *= 2;

        if (incrementalTimeout >= 5000)
          incrementalTimeout = 5000;
    }
});
/**
 * Kafka-Connect angularJS Factory
 * @see http://docs.confluent.io/3.0.1/connect/userguide.html#connectors
 */
angularAPP.service('KafkaConnectFactory', function ($rootScope, $http, $location, $q, $timeout, $mdDialog, $log, env, $injector) {

  var connectorNames = [];

  /**
   * Public API
   */
  return {

    getConnectorNames: function () {
        return connectorNames;
    },
    getConnectors: function (withMetadata) {
      var url = env.KAFKA_CONNECT() + '/connectors';
      return req('GET', url);
    },
    getConnectorInfo: function (connectorName) {
      var url = env.KAFKA_CONNECT() + '/connectors/' + connectorName;
      return req('GET', url);
    },
    getConnectorTasks: function (connectorName) {
      var url = env.KAFKA_CONNECT() + '/connectors/' + connectorName + '/tasks';
      return req('GET', url);
    },
    getConnectorStatus: function (connectorName) {

      var url = env.KAFKA_CONNECT() + '/connectors/' + connectorName + '/status';
//      return req('GET', url);
      return $http.get(url).then(function(response){
                return response;
            });
    },
    getConnectorPlugins: function () {
      var url = env.KAFKA_CONNECT() + '/connector-plugins/';
      return req('GET', url);
    },
    getConnectorConfig: function (connectorName) {
      var url = env.KAFKA_CONNECT() + '/connectors/' + connectorName + '/config';
      return req('GET', url);
    },
    postNewConnector: function (connector) {
      var url = env.KAFKA_CONNECT() + '/connectors';
      return req('POST', url, connector);
    },
    putConnectorConfig: function (connectorName, configuration) {
      var url = env.KAFKA_CONNECT() + '/connectors/' + connectorName + "/config";
      return req('PUT', url, configuration);
//      .then( function successCallback(response) {
////            _enhanceConnectorData(response)
//
//        });
    },
    deleteConnector: function (connectorName) {
      var url = env.KAFKA_CONNECT() + '/connectors/' + connectorName;
      return req('DELETE', url);
    },
    restartConnector: function (connectorName) {
      var url = env.KAFKA_CONNECT() + '/connectors/' + connectorName + "/restart";
      return req('POST', url);
    },
    pauseConnector: function (connectorName) {
      var url = env.KAFKA_CONNECT() + '/connectors/' + connectorName + "/pause";
      return req('PUT', url);
    },
    resumeConnector: function (connectorName) {
      var url = env.KAFKA_CONNECT() + '/connectors/' + connectorName + "/resume";
      return req('PUT', url);
    },
    validateConnectorConfig: function (classname, config) {
      var url = env.KAFKA_CONNECT() + '/connector-plugins/' + classname + '/config/validate'; //TODO double check that is classname here
      return req('PUT', url, config);
    },
    createCurlCommand: function (connector) {
      var data = createDataToPost(connector);
      var curlCommand = "cat << EOF > " + connector.config.name + ".json" + "\n" + angular.toJson(data, true) + "\n" + "EOF" + "\n";
      curlCommand = curlCommand + 'curl -X POST -H "Content-Type: application/json" -H "Accept: application/json" -d @' + connector.config.name + '.json ' + env.KAFKA_CONNECT() + '/connectors';
      return curlCommand;
    }
  };

   /* Private Methods */

   function req(method, url, data) {
       var deferred = $q.defer();
       var request = {
             method: method,
             url: url,
             data: data,
             dataType: 'json',
             headers: {'Content-Type': 'application/json', 'Accept': 'application/json'}
           };

       $http(request)
         .success(function (response) {
            deferred.resolve(response);
          })
         .error(function (responseError) {
              var msg = "Failed at method [" + method + "] with error: \n" + JSON.stringify(responseError);
              $log.error(msg);
              if (angular.isObject(responseError) && responseError.error_code == 404) {
                $rootScope.notExists = true;
              }
              deferred.reject(msg);
          });

       return deferred.promise;
   }

   function setConnectorNames(connectors)  {
      connectorNames = connectors;
   }

   //TODO used in curl command only
    function createDataToPost(connector) {
      var data = {
        "name": connector.config.name,
        "config": {
          "connector.class": connector.config["connector.class"],
          "tasks.max": connector.config["tasks.max"].toString()
        }
      };

      if (connector.config)
      // Some connectors have 2 topics (i.e. Yahoo) - so skip in that case
        if (connector.config["kafka.topic"] != undefined) {
          var topicKey = connector.config["kafka.topic"].property;
          data.config[topicKey] = connector.config["kafka.topic"].default;
          angular.forEach(connector.template, function (value, key) {
            data.config[key] = value;
          });
        }

      angular.forEach(connector.template, function (value, key) {
        data.config[key] = value;
      });

      angular.forEach(connector.templateNumeric, function (value, key) {
        data.config[key] = value.default.toString();
      });

      angular.forEach(connector.templateOptions, function (value, key) {
        data.config[key] = value.default;
      });

      return data;
    }


});
/**
 * Utils angularJS Factory
 */
angularAPP.factory('Spinner', function ($log, $rootScope) {

  /* Public API */
  return {
    start: function () {
      $rootScope.showSpinner = true;
    },
    stop: function () {
      $rootScope.showSpinner = false;
    }

  }

});
angularAPP.factory('supportedConnectorsFactory', function () {

 var supportedConnectors = (typeof supportedConnectorsTemplates !== "undefined") ? angular.copy(supportedConnectorsTemplates) : [];

  return {
    getSupportedConnectors : function() {
        return supportedConnectors;
    },

    getSupportedConnector: function () {
        return supportedConnectors;
    },

    matchesType: function (sourceOrSink) {
        return function(element) {
            return (element.type == sourceOrSink) && (element.uiEnabled == true); //TODO Lowercase them ?
        }
    },

    matchesName: function (name) {
        return function(element) {
            return (element.name == name) && (element.uiEnabled == true); //TODO Lowercase them ?
        }
    },

    matchesClass: function(config) {
        return matchesClass(config);
    },

    getAllClassFromTemplate: function () {
        var a =supportedConnectors.map(function (con) {
            return con.class;
        });
        return a;
    },

    getSupportedConnectorObj: function (connectorClass) {
         var filteredList = supportedConnectors.filter(matchesClass(connectorClass));
         if(filteredList.length == 1) return filteredList[0];
         //else return defaultConnectorInfo;
         else {
           var name =  connectorClass.split('.')[connectorClass.split('.').length-1]
           name = name.toUpperCase().replace('CONNECTOR', '')
           name = name.toUpperCase().replace('SINK', '')
           name = name.toUpperCase().replace('SOURCE', '')
           var connector = {name: name.substring(0,7), type: "", color: "gray", class: "" }
           return connector;
         }
    }
  };

  function matchesClass(config) {
    return function(element) {
    if (config) {
      return config.search(element.class) >= 0;
      } else {
      console.log('Null connector - Config not found');
      }
    }
  }

});
angularAPP.controller('ClusterViewCtrl', function ($scope, $log, $http, env, constants, connectorObjects, $rootScope) {

    $scope.cluster = env.getSelectedCluster().NAME;
    $scope.rebalancingMessage = constants.MESSAGE_REBALANCING;
    $scope.welcomeMessage = constants.MESSAGE_WELCOME;
    $rootScope.rebalancing = true;

    $scope.rows = [];
    $scope.sources = [];
    $scope.sinks = [];
    $scope.allTopics = [];

    $http.get(env.KAFKA_CONNECT() + '/connectors').then(function(response){
        $scope.chartHeight = response.data.length * 45;
        angular.forEach(response.data, function(con){
           $http.get(env.KAFKA_CONNECT() + '/connectors/' + con).then(function(response){
                var connector = response.data;
                var row;
                var template = connectorObjects.getConnectorTemplate(connector.config);
                var topics = connectorObjects.getTopics(connector.config);
                var workers = connector.config["tasks.max"];
                var isSource = template.type == 'Source';
                var type = template.name;
                var color = template.color;
//                var html = createCustomHTMLContent(isSource, workers, type, color);
                isSource ? $scope.sources.push(connector) : $scope.sinks.push(connector);


                angular.forEach(topics, function(t) {
                     // We are adding one space to the topic names when we add them to the diagram to avoid cyclic references when the topic name matches a connector name
                     t = t + ' '

                    if(isSource) {
                       row = {c: [ {v: connector.name}, {v: t}, {v: 1}, {v: workers + ' workers'} ]};
                       row2 = {c: [ {v: t}, {v: getRandomName()}, {v: 0.0001}, {v: ''} ]};
                    } else {
                       row2 = {c: [ {v: getRandomName()}, {v: t}, {v: 0.0001}, {v: ''} ]};
                       row = {c: [ {v: t}, {v: connector.name}, {v: 1}, {v: workers + ' workers'} ]};
                    }
                    $scope.rows.push(row);
                    $scope.rows.push(row2);

                    $scope.allTopics.push(t);
                });
           });
        });
    },
    function (reason) {
         $log.error('Failed: ' + reason);
       }, function (update) {
         $log.info('Got notification: ' + update);
       });


    $scope.chartObject = {};

    $scope.chartObject.type = "Sankey";

    $scope.chartObject.data = {
        "cols":
        [
          {id: "f", label: "From", type: "string"},
          {id: "t", label: "To", type: "string"},
          {id: "w", label: "Weight", type: "number"},
          {id: "l",  label: "A", type: "string", role: "tooltip", 'p': {'html': true}},
        ],
        "rows": $scope.rows
      };


    $scope.chartObject.options = {
        width: '100%',
         sankey: {
         node: {
                  colors: [ '#4f6672', '#37474f', '#37474F', '#202F36', '#132731' ]
                }
                ,
                link: {
                          color: { fill: '#6B7B83' }
                      }
                },
        tooltip: { isHtml: true }
    };

    //TODO move me, i am generic
    Array.prototype.contains = function(v) {
        for(var i = 0; i < this.length; i++) {
            if(this[i] === v) return true;
        }
        return false;
    };

    //TODO move me, i am generic
    Array.prototype.unique = function() {
        var arr = [];
        for(var i = 0; i < this.length; i++) {
            if(!arr.contains(this[i])) {
                arr.push(this[i]);
            }
        }
        return arr;
    }

    function getRandomName() {
    var maximum = 1000;
    var minimum = 1;
       var randomInt = Math.floor(Math.random() * (maximum - minimum + 1)) + minimum;
       var a = ' ';
      for(i = 0; i < randomInt; i++) {
            a = a + ' ';
       };
       return a;
    }
});

angularAPP.controller('KafkaConnectConfigCtrl', function ($scope, $http, $log, env, constants) {
     $scope.showVersion = false;
     $scope.kafkaConnectURL = env.KAFKA_CONNECT();
         $http.get(env.KAFKA_CONNECT()).then(function(response){
            $scope.showVersion = true;
            $scope.version =response.data.version;
        })
  $scope.connectivityError = constants.CONFIG_CONNECTIVITY_ERROR;
});

/*
    $scope.connector in this controller is the connector object from supported connectors.
    Config is created on the fly using the `template` models.
 */
angularAPP.controller('CreateConnectorCtrl', function ($scope, $rootScope, $http, $log, $routeParams, $location, $filter, KafkaConnectFactory, supportedConnectorsFactory,  NewConnectorFactory, env, constants, $q) {
  KafkaConnectFactory.getConnectorPlugins().then(function(allPlugins) {
    var className;

    for (var i in allPlugins) {
      className = allPlugins[i].class;

      if (className === $routeParams.className) {
        getClassConfig(className);
        break;
      }
    }
  }, function (reason) {
    $log.error('Failed: ' + reason);
  }, function (update) {
    $log.info('Got notification: ' + update);
  });

  $scope.prefillValues = true;
  $scope.showCurl = false;
  $scope.showDocumentation = false;
  $scope.docs = '';
  $scope.toggleShowCurl = function () { $scope.showCurl = !$scope.showCurl; };

  $scope.nextTab = function() { $scope.selectedTabIndex = ($scope.selectedTabIndex == $scope.maxNumberOfTabs) ? 0 : $scope.selectedTabIndex + 1; };
  $scope.previousTab = function() {
    $scope.selectedTabIndex = ($scope.selectedTabIndex == $scope.maxNumberOfTabs) ? 0 : $scope.selectedTabIndex - 1;
  };
  $scope.isDisabledTab = function(index) { return (index == $scope.selectedTabIndex) ? 'false' : 'true'; };


  $scope.aceLoaded = function (_editor) {
    console.log("Ace for create-connector loaded");
    $scope.editor = _editor;
    $scope.editor.$blockScrolling = Infinity;
    $scope.acePropertyFileSession = _editor.getSession();
    var lines = 15;//$scope.connectorDetails.connectorDetailsInString.split("\n").length;
    _editor.setOptions({
      minLines: lines,
      maxLines: lines,
      highlightActiveLine: false
    });
  };


  //If user changes config from the editor
  $scope.$watch('formValuesPerSection', function() {
 if ($scope.formValuesPerSection) {
      $scope.formValuesPerSection = $scope.formValuesPerSection.replace("\r", "");
      var flatValuesArray = $scope.formValuesPerSection.split("\n").filter(function (config) {
           return (config.charAt(0) !== "#");
        });
      validateConnectorFn();
  }
  });


    function validateConnectorFn () {
            var deferred = $q.defer();
            var connectorCurlObject = {
              name: "",
              config: {}
            };
            var errorConfigs = [];
            var warningConfigs = [];

            flatValuesArray = $scope.formValuesPerSection.split("\n").filter(function (config) {
                 return (config.charAt(0) !== "#");
              });
            config = NewConnectorFactory.getJSONConfigFlat(flatValuesArray);

            // Make sure the 'classname' is a valid one - as it can crash the connect services
            var classname = flatValuesArray.find(function (p) {
                 return (p.indexOf("connector.class=") == 0)
            }).split('connector.class=').join('');
            if (classname != $scope.connector.class) {
                console.log("error in classname -> " + classname);
                var errors = { errors : [ 'Classname "' + $scope.connector.class + '" is not defined' ] };
                errorConfigs.push(errors);

                if(errorConfigs == 0) {
                    $scope.validConfig = constants.VIEW_MESSAGE_CONNECTOR_VALID;
                    $scope.curlCommand = NewConnectorFactory.getCurlCommand(flatValuesArray);
                }
                $scope.errorConfigs = errorConfigs;
            }

            //console.log("Error configs -> " + errorConfigs);
            //console.log(errorConfigs.length == 0);

            //STEP 1: Validate
            var validateConfigPromise = KafkaConnectFactory.validateConnectorConfig(classname, config);
            validateConfigPromise.then(
                function success(data) {
                  $log.info('Total validation errors from API => ' + data.error_count);
                  //STEP 2: Get errors if any
                  $scope.validConfig = '';
                  var validConnectorConfigKeys = [];
                  var requiredConfigKeys = [];
                  angular.forEach(data.configs, function (config) {
                    //console.log("c-> " + config.value.name);
                    //console.log(config);
                    if (config.value.errors.length > 0) {
                        errorConfigs.push(config.value);
                        $log.info(config.value.name + ' : ' + config.value.errors[0]);
                    }
                    //console.log("config.value -> ");
                    if ( (config.definition.required == true) || ( (config.value.name.indexOf("topic") == 0) && (config.definition.documentation != "") ) ) {
                      requiredConfigKeys.push(config.value.name);
                    }
                    validConnectorConfigKeys.push(config.value.name);
                  });
                  console.log("Required/compulsory config keys: " + requiredConfigKeys);
                  //console.log("validConnectorConfigKeys -> " + validConnectorConfigKeys);
                  angular.forEach(flatValuesArray, function (propertyLine) {
                    if (propertyLine.length > 0) {
                      if ( (propertyLine.indexOf("=") == -1) | (propertyLine.length < 3) ) {
                        var errors = { errors : [ 'Line "' + propertyLine + '" is not a valid property line' ] };
                        errorConfigs.push(errors);
                      } else {
                          var key = propertyLine.substring(0, propertyLine.indexOf('='));
                          var value = propertyLine.substring(propertyLine.indexOf('=') + 1);
                          if (validConnectorConfigKeys.indexOf(key) === -1) {
                            var warning = { warnings : [ 'Warning: Config "' + key + '" is unknown' ] };
                            warningConfigs.push(warning);
                          } else if (value.length === 0) {
                            var errors = { errors : [ 'Config "' + key + '" requires a value' ] };
                            errorConfigs.push(errors);
                          } else {
                            connectorCurlObject.config["" + key] = value;
                          }
                      }
                    }
                  });
                  // Now check the other way around. Whether a required property is not set
                  angular.forEach(requiredConfigKeys, function (requiredKey) {
                    var x = flatValuesArray.find(function(p) {
                      var result = (p.indexOf(requiredKey) == 0);
                      return result
                    });
                    //console.log("x " + requiredKey + "   " +  x)
                    if (x == undefined) {
                      var errors = { errors : [ 'Required config "' + requiredKey + '" is not there' ] };
                      errorConfigs.push(errors);
                    };
                  });

                  if(errorConfigs == 0) {
                      $scope.validConfig = constants.VIEW_MESSAGE_CONNECTOR_VALID;
                      $scope.curlCommand = NewConnectorFactory.getCurlCommand(flatValuesArray);
                      deferred.resolve(constants.VIEW_MESSAGE_CONNECTOR_VALID);
                  } else {
                      deferred.reject(errorConfigs);
                  }
                  $scope.errorConfigs = errorConfigs;
                  $scope.warningConfigs = warningConfigs;

                  /* debug
                  var flatKeysUsed = [];
                  angular.forEach(flatValuesArray, function (propertyLine) {
                      flatKeysUsed.push(propertyLine.split("=" , 1) + "");
                  });
                  console.log(validConnectorConfigKeys);
                  console.log(flatKeysUsed);
                  console.log(errorConfigs);
                  */
                },
                function error(data, reason) {
                  $log.error('Failure : ' + data);
                  deferred.reject(data);
                });
                return deferred.promise;
    }

  $scope.validateConnector = function () {
    validateConnectorFn();
  }


  $scope.validateAndCreateConnector = function () {

          validateConnectorFn().then(
            function success(data) {
              console.log("I will now post the connector");
              KafkaConnectFactory.postNewConnector(NewConnectorFactory.getJSONConfig(flatValuesArray)).then(
                function successCallback(response) {
                   console.log("POSTING " + JSON.stringify(response));
                   $location.path("#/connector/" + response.name); //TODO location doesn't work, move to controller
                   $rootScope.newConnectorChanges = true;
                });
            }, function (data, reason) {
              $scope.validConfig = "Please fix the below issues";
              console.log("I can NOT post the connector - as validation errors exist");
          });

    }


  $scope.querySearch = function(query){
        return $http.get(env.KAFKA_REST() + '/topics')
        .then(function(response){
          return response.data.filter( function(topic) { return topic.indexOf(query) > -1 });
        })
      }; //for the autocomplete

  $scope.simpleName = function(connectorName) {
    if ((connectorName != undefined) && (connectorName.length > 10)) {
        return connectorName.replace('SourceConnector', '').replace('SinkConnector', '').replace('Stream','');
    } else {
        return "";
    }
  };

  function getClassConfig (pluginClass){
    var type="Unknown";
    var a = pluginClass.split('.');
    if (a[a.length-1].toLowerCase().indexOf('sink') > 0) {
      type="Sink";
      var myElements = [{key:'name',value: a[a.length-1], required: true}, {key:'connector.class', value: pluginClass, required: true},{key:'topics',value: 'TopicName_'+ a[a.length-1], required: true}, {key:'tasks.max',value: 1, required: true}];
    } else if (a[a.length-1].toLowerCase().indexOf('source') > 0) {
      type="Source";
      var myElements =  [{key:'name',value: a[a.length-1], required: true}, {key:'connector.class', value: pluginClass, required: true}, {key:'tasks.max',value: 1, required: true}];
    }

     // Find the correct connector Icon & documentation
     var connectorIcon = "connector.jpg";
     angular.forEach(supportedConnectorsTemplates, function (template) {
        if (template.class == pluginClass) {
            connectorIcon = template.icon;
            $http.get('src/documentation/' + template.docs).then(function(response){
                $scope.docs = response.data;
            });
        }
     });

     var connector = {
      name: a[a.length-1],
      class: pluginClass,
      icon: connectorIcon,
      isUndefined: true,
      type: type,
      template : [
       {
         step : "Basic Info",
         id : "step1",
         sections : [
         {
          elements : myElements
          }
         ]
       }
      ]
     }

    var request = {
       method: 'PUT',
       url: env.KAFKA_CONNECT() + '/connector-plugins/' + pluginClass + '/config/validate',
       data: '{ "connector.class" : "' + pluginClass + '" }',
       dataType: 'json',
       headers: {'Content-Type': 'application/json', 'Accept': 'application/json'}
    };

    $http(request).then(function(data){
    angular.forEach(data.data.configs, function (config) {
      if (config.definition.name !== 'name' && config.definition.name !== 'connector.class' && config.definition.required == true) {
         connector.template[0].sections[0].elements.push({
           key: config.definition.name,
           value: config.definition.default_value ? config.definition.default_value : '',
           required: config.definition.required
         });
      }
    });
    function compare(a,b) {
      if (a.required < b.required)
        return 1;
      if (a.required > b.required)
        return -1;
      return 0;
    }
    connector.template[0].sections[0].elements.sort(compare);
    return connector;
    }).then(function(connector) {
       $scope.connector = angular.copy(connector);
       $scope.maxNumberOfTabs = 1
       $scope.selectedTabIndex = 1
       var configValues = NewConnectorFactory.flattenConnectorKeyValues($scope.connector);
       $scope.formValuesPerSection = configValues.join("\n");
       $scope.curlCommand = NewConnectorFactory.getCurlCommand(configValues);
    });
  }

$scope.getAllConfig = function (pluginClass){
  if ($scope.showAllConfig !== true) {
   var request = {
         method: 'PUT',
         url: env.KAFKA_CONNECT() + '/connector-plugins/' + pluginClass + '/config/validate',
         data: '{ "connector.class" : "' + pluginClass + '" }',
         dataType: 'json',
         headers: {'Content-Type': 'application/json', 'Accept': 'application/json'}
      };
      $scope.allValues =  {template : [{sections : [{elements : []}]}]};
      $http(request).then(function(data){
       angular.forEach(data.data.configs, function (config) {
         if ($scope.formValuesPerSection.indexOf(config.definition.name) < 0) {
            $scope.allValues.template[0].sections[0].elements.push({
              key: config.definition.name,
              value: config.definition.default_value ? config.definition.default_value : '',
              required: config.definition.required
            });
         }
      });
    }).then(function() {
    $scope.configAllValues = NewConnectorFactory.flattenConnectorKeyValues($scope.allValues);

    if ($scope.configAllValues.length > 0){
        $scope.formValuesPerSection = $scope.formValuesPerSection + '\n' +  $scope.configAllValues.join("\n");
        $scope.showAllConfig = true
        $scope.noextraconfig = false
        } else {
        $scope.noextraconfig = true
        }
     });
  } else {
    if ($scope.configAllValues.length > 0){
      $scope.formValuesPerSection = $scope.formValuesPerSection.replace('\n'+ $scope.configAllValues.join("\n"), '');
    }
    $scope.showAllConfig = false;
  }
}

$scope.showConnectorDocumentation = function(pluginClass) {
    $scope.showDocumentation = !$scope.showDocumentation;
}

});
angularAPP.controller('ExportConfigsCtrl', function ($scope, $rootScope, env, KafkaConnectFactory, NewConnectorFactory, $http, $routeParams, $templateCache, $log, connectorObjects, constants) {
    $scope.cluster = env.getSelectedCluster().NAME;
    $rootScope.rebalancing = true;
    $scope.properties = [];
    $scope.jsons = ''
    $scope.curls = [];
    var d = new Date()
 		$scope.date = '-'+d.getDate()+''+(d.getMonth()+1)+''+d.getFullYear()+''+d.getHours()+''+d.getMinutes()
    $http.get(env.KAFKA_CONNECT() + '/connectors').then(function(response){
        angular.forEach(response.data, function(con){
           $http.get(env.KAFKA_CONNECT() + '/connectors/' + con).then(function(response){
//                $scope.allConnectors.push(angular.toJson(response.data.config, true));

                //properties modes
                var a = configToProperties(response.data.config)
                $scope.properties.push('# '+ response.data.name + '\n\n'+a.join("\n"));
//                $scope.propertiesStr = $scope.propertiesStr + '# '+ response.data.name + '\n\n'+a.join("\n");


                //curl modes
                $scope.curls.push(NewConnectorFactory.getCurlCommand(configToProperties(response.data.config)));

                //edit modes
                $scope.jsons = $scope.jsons +
                                            '/*** ' + response.data.name + ' ***/ \n\n' +
                                            angular.toJson(response.data.config, true) + '\n\n';


                var propertiesBlob = new Blob([ $scope.propertiesStr ], { type : 'text/plain' });
                $scope.propertiesURL = (window.URL || window.webkitURL).createObjectURL( propertiesBlob );

                var jsonsBlob = new Blob([ $scope.jsons ], { type : 'text/plain' });
                $scope.jsonsURL = (window.URL || window.webkitURL).createObjectURL( jsonsBlob );

                var curlsBlob = new Blob([ $scope.curlsStr ], { type : 'text/plain' });
                $scope.curlsURL = (window.URL || window.webkitURL).createObjectURL( curlsBlob );
           })
        });

    })




    function configToProperties(config) {
        var conProps = [];
        angular.forEach(config, function(k,v) {
         conProps.push((v +"="+k));
        });
        return conProps;
    }

});



angularAPP.controller('HomeCtrl', function ($scope, $log, $location, $http, $interval, env, constants, connectorObjects, $rootScope) {

    var envs = env.getClusters();
    $rootScope.isHome = true;

    $scope.loadData = function () {

       $scope.stopRefresh = false;

       $scope.envs = [];
       $scope.totalConnectors = 0;
       $scope.failedClusters = 0;

       angular.forEach(envs, function(env) {

            var e = {
                name : "", connect : "", version: "", status : "", connectors : ""
            }

            e.name = env.NAME;
            e.connect = env.KAFKA_CONNECT;

            $http.get(env.KAFKA_CONNECT).then(function (response) {
                e.version = response.data.version;
                e.status = response.status;
                $http.get(env.KAFKA_CONNECT + "/connectors").then(function(response) {
                    e.connectors = response.data.length;
                    $scope.totalConnectors += e.connectors;
                })
            }).catch(function (response) {
                // Handle error here
                 e.status = response.status;
                 e.version = "N/A"
                 e.status = "N/A"
                 e.connectors = "N/A"

                 $scope.failedClusters += 1;
            });

            $scope.envs.push(e);

       })

   }

   //On load

   if(envs.length > 1) {
      $scope.loadData();
   } else {
      $location.path("/cluster/"+envs[0].NAME);
   }

   $interval(refresh, 10000);

   function refresh() {
    if(!$scope.stopRefresh) $scope.loadData();
   }

   //Go to cluster

   $scope.updateEndPoint = function(cluster, status) {
    if (status >= 200 && status < 400) {
        $rootScope.connectionFailure = false;
        $scope.stopRefresh = true;
        $location.path("/cluster/"+cluster);
    }
   }
});

angularAPP.controller('KafkaConnectListCtrl', function ($scope, $rootScope, KafkaConnectFactory, $routeParams, $templateCache, $log, connectorObjects, constants, env) {

   $scope.noConnectorsFoundMessage = constants.LIST_NO_CONNECTORS_FOUND;
   $scope.rebalancingMesasge = constants.MESSAGE_REBALANCING;
  /**
   * Watch the 'newConnectorCreated' and update the connect-cache accordingly
   * TODO: Use it
   */
  $scope.$watch(function () {
    return $rootScope.newConnectorChanges;
  }, function (a) {
    if ($rootScope.newConnectorChanges) {
        initConnectors();
   }
  }, true);

  $scope.$on('$routeChangeSuccess', function() {
       $scope.cluster = env.getSelectedCluster().NAME;//$routeParams.cluster;
      initConnectors();
  })


   $scope.getTaskStates = function(connector) {
    return connector.tasks.map(function(task){ return task.state; }).indexOf('FAILED') !== -1;
    $rootScope.rebalancing = true;
   }

   function initConnectors(){
    connectorObjects.getConnectorList().then(function (allConnectors) {
        $scope.allConnectors = allConnectors;
        $rootScope.loading = false;
        $rootScope.rebalancing = false;
        $rootScope.newConnectorChanges = false;
      });
   }

});
angularAPP.controller('SelectNewConnectorCtrl', function ($scope, $http, $log, $rootScope, KafkaConnectFactory, supportedConnectorsFactory, env) {
  $log.info("SelectNewConnector controller");

  var classpathMap = {};

  $scope.cluster = env.getSelectedCluster().NAME;

  var supportedConnectors = supportedConnectorsFactory.getSupportedConnectors();
  if (supportedConnectors.length != 0) {
    $scope.sources = supportedConnectors.filter(supportedConnectorsFactory.matchesType('Source'));
    $scope.sinks = supportedConnectors.filter(supportedConnectorsFactory.matchesType('Sink'));
  }

  $scope.unsupportedConnectors = [];
  $scope.hasUnsupportedConnectors = false;

  $scope.isClassInClasspath = isClassInClasspath;

  KafkaConnectFactory.getConnectorPlugins().then(function (allPlugins) {
    angular.forEach(allPlugins, function (plugin) {
      classpathMap[plugin.class] = true;

      if (supportedConnectorsFactory.getAllClassFromTemplate().indexOf(plugin.class) == -1) {
        $scope.hasUnsupportedConnectors = true;
          var type="Unknown";
          var a = plugin.class.split('.');
          if (a[a.length-1].toLowerCase().indexOf('sink') > 0) {
          type="Sink"
          } else if (a[a.length-1].toLowerCase().indexOf('source') > 0) {
          type="Source"
          }
         var o = {
            name: a[a.length-1],
            class: plugin.class,
            icon: "connector.jpg",
            isUndefined: true,
            type: type
        }
        if (type == "Source")
        $scope.sources.push(o);
        else
        $scope.sinks.push(o);
      }
    });
  }, function (reason) {
    $log.error('Failed: ' + reason);
  }, function (update) {
    $log.info('Got notification: ' + update);
  });

  /**
   * @description Determines if the specified class name is in the classpath
   * @param {String} className
   * @returns {Boolean}
   */
  function isClassInClasspath(className) {
    return angular.isDefined(classpathMap[className]);
  }
});

angularAPP.controller('ConnectorDetailCtrl', function ($rootScope, $scope, $routeParams, $timeout, $log, $location, $mdDialog, KafkaConnectFactory, connectorObjects, constants, env) {

  $rootScope.selectedConnector = $routeParams.runningConnector;
  var runningConnector = $routeParams.runningConnector;
  var selectedConnector =  $routeParams.runningConnector;
  $scope.invalidSyntaxMessage = constants.VIEW_EDITOR_INVALID_SYNTAX;
  $scope.kafkaTopicsUI = env.KAFKA_TOPICS_UI();
  $scope.kafkaTopicsUIEnabled = env.KAFKA_TOPICS_UI_ENABLED();
  $scope.aceReady = false;
  $scope.connectorConfigurationEditable = true;
  $rootScope.rebalancing = true;
  $scope.showConfigSpinner = false;
  $scope.showTaskSpinner = false;
  $scope.actionsDisabled = true;
  init();

  function deepEqual(x, y) {
    const ok = Object.keys, tx = typeof x, ty = typeof y;
    return x && y && tx === 'object' && tx === ty ? (
      ok(x).length === ok(y).length &&
        ok(x).every(key => deepEqual(x[key], y[key]))
    ) : (x === y);
  }

  $scope.showTaskDetails = function (task) {
     // So that it closes the panel if it is clicked a second time
     if (deepEqual($scope.selectedTask , getSelectedTask($scope.connectorDetails.detailedTasks, task))) {
       console.log("Closing selected Task - as was clicked");
       $scope.selectedTask = null;
     } else {
        $scope.selectedTask = getSelectedTask($scope.connectorDetails.detailedTasks, task);
     }
     console.log(getSelectedTask($scope.connectorDetails.detailedTasks, task));
  };

  $scope.getCleanTopic = function (topic) {
    if (topic instanceof Array) {
        return topic.join(' ').split(':')[topic.length];
    } else {
        return topic;
    }
  };

  $scope.invalidateSelectedTask = function() {
    $scope.selectedTask = null;
  }

  $scope.pauseConnector = function (connectorName) {
    $rootScope.newConnectorChanges = true;
    KafkaConnectFactory.pauseConnector(connectorName).then(function(data) { init(); });
  };

  $scope.resumeConnector = function (connectorName) {
    $rootScope.newConnectorChanges = true;
    KafkaConnectFactory.resumeConnector(connectorName).then(function(data) { init(); });
  };

  $scope.restartConnector = function (connectorName) {
    KafkaConnectFactory.restartConnector(connectorName).then(function(data) { init(); });
    $rootScope.newConnectorChanges = true;
  };

  $scope.validateConnector = function (object, _editor) {
      $scope.validConfig = "";
      KafkaConnectFactory.validateConnectorConfig(object.config["connector.class"], $scope.connectorDetails.connectorDetailsInString).then(
        function(data) {
          $scope.errorConfigs = parseValidationErrors(data);
          $scope.aceValidate(_editor);
          if($scope.errorConfigs.length == 0) {
              $scope.validConfig = constants.VIEW_MESSAGE_CONNECTOR_VALID;
          }
      });
  };

  $scope.updateConnector = function (connectorName, event, _editor) {
    $mdDialog.show(dialog('UPDATE', event)).then(function() {
        $scope.invalidateSelectedTask();
        updateConnector($scope.connectorDetails, _editor);
      });
  };

  $scope.deleteConnector = function (connector, event) {
    $mdDialog.show(dialog('DELETE', event)).then(function() {
       deleteConnector(connector);
    });
  };

  $scope.toggleEditor = function () {
    $scope.connectorConfigurationEditable = !$scope.connectorConfigurationEditable;
    if (!$scope.connectorConfigurationEditable) {
        $scope.aceBackgroundColor = "rgba(0, 128, 0, 0.04)";
        $scope.showSyntaxValidation = true;
    } else {
        $scope.aceBackgroundColor = "#fff";
        $scope.validConfig = "";
        $scope.showSyntaxValidation = false;
        invalidateEditorMarkers();
        $scope.errorConfigs = null;
    }
  };

  $scope.cancelEditor = function() {
    $scope.connectorDetails.connectorDetailsInString = $scope.connectorDetailsInStringBefore;
    $scope.toggleEditor();
  }

  $scope.aceLoaded = function (_editor) {
    console.log("Ace loaded");
    $scope.editor = _editor;
    $scope.editor.$blockScrolling = Infinity;
    $scope.acePropertyFileSession = _editor.getSession();
    var lines = $scope.connectorDetails.connectorDetailsInString.split("\n").length;
    _editor.setOptions({
      minLines: lines,
      maxLines: lines,
      highlightActiveLine: false
    });
  };

  $scope.aceChanged = function (_editor) {
    $scope.editor = _editor;
    $scope.editor.$blockScrolling = Infinity;
    var aceContent = $scope.acePropertyFileSession.getDocument().getValue();
    $scope.connectorDetails.connectorDetailsInString = aceContent;
  };

  var  markerRange;
  $scope.aceValidate = function (_editor) {
      var Range = ace.require('ace/range').Range;
      invalidateEditorMarkers();
      var errorLines = calculateErrorLines();
      $scope.errorIds = [];
      angular.forEach(errorLines, function (errorline) {
        markerRange = new Range(errorline, 1, errorline, 2);
        markerRange.id =  $scope.acePropertyFileSession.addMarker( markerRange, "myMarker", "fullLine", "ace_error");
        $scope.errorIds.push(markerRange.id );
      });
   };

  $scope.$watch('connectorDetails.connectorDetailsInString', function() {
       if($scope.connectorDetails != undefined && $scope.connectorDetailsInStringBefore != undefined) {
            if($scope.connectorDetails.connectorDetailsInString.trim() == $scope.connectorDetailsInStringBefore.trim()) {
                $scope.actionsDisabled = true
            } else {
                $scope.actionsDisabled = false;
            }
       }
  });

  function init() {
   $log.info("initializing controller state..")
   connectorObjects.getConnector(selectedConnector).then(
      function success(connectorDetails) {
        $scope.connectorDetails = connectorDetails;
        $scope.aceReady = true;
        $scope.connectorDetailsInStringBefore = angular.toJson(connectorDetails.config, true);
        $scope.showTaskSpinner = false;
        $scope.showConfigSpinner = false;
        $rootScope.loading = false;
        $rootScope.rebalancing = false;
        $rootScope.newConnectorChanges = false;
      });
  }

  function updateConnector(connectorDetails, _editor) {
      $scope.validConfig = "";
      var connectorDetailsInString = connectorDetails.connectorDetailsInString;

      KafkaConnectFactory
            .validateConnectorConfig(connectorDetails.config["connector.class"], connectorDetailsInString)
            .then(function successCallback(data) {
                  var errorConfigs = parseValidationErrors(data);
                  if(errorConfigs.length == 0) {
                        $scope.toggleEditor();
                        $scope.showConfigSpinner = true;
                        $scope.showTaskSpinner = true;
                        KafkaConnectFactory
                               .putConnectorConfig(connectorDetails.name, connectorDetailsInString)
                               .then(function successCallback(data) { //TODO we ignore the response completely
                                  $scope.showConfigSpinner = false;
                                  $rootScope.newConnectorChanges = true;
                                  $timeout (function () { init(); }, 10000);
                               }, function errorCallback(response) {
                                  $scope.showConfigSpinner = false;
                                  $scope.showTaskSpinner = false;
                               });
                  } else {
                      $scope.errorConfigs = errorConfigs
                      $scope.aceValidate(_editor);
                  }
            });
  }

  function deleteConnector(connector) {
    KafkaConnectFactory.deleteConnector(connector).then(function (success) {
      $log.info('Success in connector deletion. Redirecting to / ');
      $rootScope.newConnectorChanges = true;
      $location.path("/#/");
    });
  }

  function parseValidationErrors(validationResponse) {
        $log.info('Total validation errors => ' + validationResponse.error_count);
        var errorConfigs = [];
          angular.forEach(validationResponse.configs, function (config) {
            if (config.value.errors.length > 0) {
                errorConfigs.push(config.value);
                $log.info(config.value.name + ' : ' + config.value.errors[0]);
            }
        });
        return errorConfigs;
    }

  function getSelectedTask(detailedTasks, task) {
     var selectedTask = { taskStatus : task, taskConfig : {} };
     angular.forEach(detailedTasks, function (ftask) {
        if(ftask.id.task == task.id) selectedTask.taskConfig = ftask;
     });
     return selectedTask
  }

  function dialog(type, event) {
    var dialog;
    switch(type) {
        case 'DELETE':
            dialog = $mdDialog.confirm()
                .title('Delete connector')
                .textContent("This will halt all tasks, and delete the connector and it's configuration")
                .targetEvent(event)
                .ok('DELETE')
                .cancel('CANCEL');
            break;
        case 'UPDATE':
            dialog = $mdDialog.confirm()
                .title('Are you sure you want to update the connector?')
                .textContent("This may rebalance and restart the connect cluster")
                .targetEvent(event)
                .ok('UPDATE')
                .cancel('CANCEL');
            break;
//        default:
//            default ""
    }
    return dialog;
  }

  function invalidateEditorMarkers() {
    angular.forEach($scope.errorIds, function (errorId) {
        $scope.acePropertyFileSession.removeMarker(errorId);
    });
  }

  function calculateErrorLines() {
      var errorLines = [];
      var keys = Object.keys(angular.fromJson($scope.connectorDetails.connectorDetailsInString));
      angular.forEach($scope.errorConfigs, function(error){
          var line = keys.indexOf(error.name) + 1;
          if (line != 0)
          errorLines.push(line);
      });
      return errorLines;
  }
});




